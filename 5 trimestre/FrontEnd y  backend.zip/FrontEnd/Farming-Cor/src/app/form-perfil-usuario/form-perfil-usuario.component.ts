import { Component } from '@angular/core';

@Component({
  selector: 'app-form-perfil-usuario',
  templateUrl: './form-perfil-usuario.component.html',
  styleUrls: ['./form-perfil-usuario.component.css']
})
export class FormPerfilUsuarioComponent {

}

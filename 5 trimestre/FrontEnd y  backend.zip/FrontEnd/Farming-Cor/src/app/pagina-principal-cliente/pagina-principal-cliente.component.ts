import { Component } from '@angular/core';

@Component({
  selector: 'app-pagina-principal-cliente',
  templateUrl: './pagina-principal-cliente.component.html',
  styleUrls: ['./pagina-principal-cliente.component.css']
})
export class PaginaPrincipalClienteComponent {

}
